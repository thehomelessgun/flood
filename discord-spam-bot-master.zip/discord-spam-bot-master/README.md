# Discord Spam Bot

This is a quite simple spam bot. It has one command, /spam, which takes two arguments, like so:
```
/spam <amount> <message>
```
An example usage would be
```
/spam 10 Hello World
```

# Disclaimer
The use of this bot may violate Discord's Terms of Service.
We are providing the source free of charge and are NOT responsible for any damages you cause with it.
Use it at your own risk!
